-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-11-2021 a las 21:08:37
-- Versión del servidor: 10.4.20-MariaDB
-- Versión de PHP: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pd3`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `artistas`
--

CREATE TABLE `artistas` (
  `id` int(8) NOT NULL,
  `nombre` varchar(30) COLLATE utf8mb4_spanish_ci NOT NULL,
  `apellido` varchar(30) COLLATE utf8mb4_spanish_ci NOT NULL,
  `bio` text COLLATE utf8mb4_spanish_ci NOT NULL,
  `foto` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `artistas`
--

INSERT INTO `artistas` (`id`, `nombre`, `apellido`, `bio`, `foto`) VALUES
(1, '<h1>Filippo Tommaso', 'Marinetti</h1>', '<p>Filippo Tommaso Marinetti fue un poeta, escritor, ideólogo fascista, dramaturgo y editor italiano del siglo XX.</p>\r\n\r\n<p>Conocido por ser el fundador del movimiento futurista, la primera vanguardia italiana del novecento y que sirvió como base para el fascismo de Mussolini. Se dio a conocer con un pequeño poema, Les vieux marins (1897), que obtuvo el primer premio de los Samedis populaires y que, junto con sus siguientes obras, el poema La conquete des étoiles (1902), el volumen de versos Destruction (1904) y la tragedia Le Roi Bombance (1905), contribuyó a difundir en Italia la poesía decadente y simbolista.</P>\r\n\r\n<p>En 1905 fundó la revista Poesía, donde pudieron publicar sus primeros versos muchos jóvenes aún desconocidos.\r\nSin embargo, su decidida ruptura con la tradición se reflejará en el primer Manifiesto del futurismo (1909), publicado en el diario parisino Figaro, en el Manifiesto de la lite ratura futurista (1910) y en el Manifiesto técnico del futurismo (1912). En ellos exaltó una nueva civilización gobernada por las máquinas y la velocidad, defendió la violencia y la guerra, entendida como única posibilidad de afirmación individual, y concibió una nueva expresividad, propuesta a través de la destrucción de la sintaxis y de la abolición del adjetivo, del adverbio y de la puntuación, con la intención de reflejar las sensaciones inmediatas de la vida moderna y de captar con violencia la atención del lector.</p>', 'img/filippo.jpg'),
(2, '<h1>Giacomo', ' Balla</h1>', '<p>Giacomo Balla es un pintor italiano, uno de los más destacados representantes del futurismo. <p>Trasladado a Roma en 1895, se dedicó a pintar escenas nocturnas y exteriores de la ciudad. Con posterioridad, abandonó el academicismo de sus primeros trabajos para seguir los postulados futuristas de Marinetti, y fue uno de los firmanes del Manifiesto de 1910.</p>\r\n<p>Imbuido en esta etapa de las ideas futuristas y de su apología de la modernidad, Giacomo Balla buscó en sus lienzos la re presentación de la rapidez y el movimiento.</P>\r\n<p>Muestra de ello es Dinamismo de un perro con correa (1912), cuadro que ejemplifica la búsqueda científica de la plasmación del movimiento, uno de los principales objetivos de los futuristas.</p> \r\n<p>La sensación del desplazamiento de los cuerpos se conseguía a través de la representación simultánea de cada una de las posiciones adoptadas al moverse, como puede apreciarse en los pasos dados por el perro y su dueña, así como en la oscilación de la correa del animal. A una técnica similar recurrirían los dibujos animados y los cómics.</p>', 'img/giacomo.jpg'),
(3, '<h1>Gino', 'Severini</h1>', '<p>Gino Severini es un pintor italiano. Profundizó en el divisionismo con el estudio del impresionismo y de la obra de Seurat, y en 1910 se adhirió al futurismo.</p>\r\n\r\n<p>La influencia del cubismo, ya presente en 1910, resulta más evidente y personal en 1914. A partir de 1923 se dedicó principalmente a realizar paneles decorativos y mosaicos para casas privadas e iglesias, en un acercamiento al novecento italiano. Hacia los años cuarenta volvió a una pintura de raíz neocubista y abierta a la abstracción geométrica. Destacan también sus ensayos Del cubismo al clasicismo (1921) y Razonamientos sobre las artes figurativas (1936).</p>\r\n\r\n<p>La vocación de Gino Severini le hizo trasladarse a Roma en busca de fortuna. Allí entró en relación con Umberto Boccioni y frecuentó el estudio de Giacomo Balla, pero a tenor del escaso éxito de sus pinturas en la Mostra de Rifiutati en el Teatro Constanza (1905), hubo de pasar a París, donde recibió con entusiasmo, pero también con reservas, el manifiesto futurista de 1910.</p>\r\n\r\n<p>La vanguardia cubista francesa y el apasionamiento propio del futurismo italiano están presentes en buena parte de su obra, como se percibe en las líneas rectas y agresivas, la aplicación de los colores al modo del neoimpresionismo de Georges Seurat y el tono irreverente típico de los artistas de entreguerras.</p>', 'img/gino.jpg'),
(4, '<h1>Umberto', 'Boccioni</h1>', '<p>Pintor y escultor italiano. Figura clave del movimiento futurista italiano, fue también uno de sus más destacados te óricos. Se inició en el divisionismo de la mano de Giacomo Balla. Después de pasar algún tiempo en París, Rusia, Padua y Venecia, se instaló definitivamente en Milán y se interesó por todo lo referente a la sociedad industrial moderna.</p>\r\n\r\n<p>Boccioni desarrolló conceptos clave para el desarrollo formal del futurismo como el de líneas-fuerza, simultaneidad, compenetración de planos y expansión de los cuerpos en la superficie . Conceptos todos ellos que reiteran una idea fundamental: la reciprocidad de relaciones entre los objetos y entre éstos y el ambiente que los circunda.</p>\r\n\r\n<p>Pinturas como “La ciudad que surge” y “La calle ante la casa” son encarnaciones de un mismo tema: la ciudad como síntesis de un movimiento vibrante y luminoso. En ambas, el dinamismo está generado por una red de líneas de fu erza que estructuran la composición.</p>\r\n\r\n<p>La primera está conformada por una tupida re d de pinceladas enérgicas, cuyos cambios direccionales enfatizan la sensación dinámica del conjunto.</p>\r\n\r\n<p>La segunda, sin embargo, es una asimilación de las formas y el espacio a la fragmentación del cubismo analítico. Y es que para el futurismo, el tema es mucho más importante que la forma.</p>', 'img/umberto.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(8) NOT NULL,
  `nombre` varchar(30) COLLATE utf8mb4_spanish_ci NOT NULL,
  `apellido` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `usuario` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellido`, `email`, `usuario`, `password`) VALUES
(6, 'kim', '', 'aracelikim00@gmail.com', 'arakim', '202cb962ac59075b964b07152d234b70'),
(7, 'ara', 'kim', 'aracelikimm@gmail.com', 'araa', '202cb962ac59075b964b07152d234b70'),
(8, 'ara', 'kim', 'aa@gmail.com', 'araa', '81dc9bdb52d04dc20036dbd8313ed055'),
(9, 'araceli', 'kim', 'arakim00@gmail.com', 'arak', '81dc9bdb52d04dc20036dbd8313ed055'),
(10, 'gabi', 'koh', 'gabiii@gmail.com', 'gabikoh', '81dc9bdb52d04dc20036dbd8313ed055'),
(11, 'ara', 'kiim', 'arak@gmail.com', 'frutilla', '81dc9bdb52d04dc20036dbd8313ed055'),
(12, 'belen', 'perez', 'belup@gmail.com', 'belup', '202cb962ac59075b964b07152d234b70'),
(13, 'araceli', 'kim', 'aracelikim@gmail.com', 'arakimm', '202cb962ac59075b964b07152d234b70'),
(14, 'hh', 'aa', 'aa@aa', 'aa', '4124bc0a9335c27f086f24ba207a4912');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `artistas`
--
ALTER TABLE `artistas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `artistas`
--
ALTER TABLE `artistas`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
