<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Futurismo</title>
	<link href="css/estilo.css" rel="stylesheet" type="text/css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Noto+Sans+JP:wght@500&family=Oxygen:wght@300&family=Shadows+Into+Light&display=swap" rel="stylesheet">
  </head>
<header class="titulo">
	<a href="index.html"><img src="img/futu.jpg" alt="inicio"></a>
</header>
<body>
	
<div class="container">
	<div class="d-flex justify-content-center">
	<div class="float-none">
	<nav class="navbar navbar-expand-lg navbar-light" style="background-color:#9ec9ae;">
	  <div class="container-fluid">
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
		  <span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
		  <ul class="navbar-nav">
			<li class="nav-item">
			  <a class="nav-link" href="historia.html">Historia</a>
			</li>
			<li class="nav-item">
			  <a class="nav-link" href="artistas.html">Artistas</a>
			</li>
			<li class="nav-item">
			  <a class="nav-link" href="obras.html">Obras</a>
			</li>
			<li class="nav-item">
			  <a class="nav-link" href="noticias.html">Noticias</a>
			</li>
			<li class="nav-item">
			  <a class="nav-link" href="conectarse.html">Conectarse</a>
			</li>
			<li class="nav-item">
			  <a class="nav-link" href="contacto.html">Contacto</a>
			</li>
		  </ul>
			
	<div class="busc">
	<form action="resultados_buscar.php" method="post">
    <input type="search" name="buscar" placeholder="Buscar..." />
    <input type="submit" value="Enviar">
    </form>
	</div>
		</div>
	  </div>
	</nav>
	</div>
	</div>
	</div>
	
	
<section>
<?php
$conexion = mysqli_connect('localhost', 'root','', 'pd3');

	$buscar = $_POST['buscar'];
	echo "Su consulta: <em>".$buscar."</em><br>";

	$consulta = mysqli_query($conexion, "SELECT * FROM artistas WHERE nombre LIKE '%$buscar%' OR apellido LIKE '%$buscar%' ");
?>
<article style="width:60%;margin:0 auto;border:solid;padding:10px;">
	<p>Cantidad de Resultados: 
	<?php
		$nros=mysqli_num_rows($consulta);
		echo $nros;
	?>
	</p>
    
	<?php
		while($resultados=mysqli_fetch_array($consulta)) {
	?>
    <p>
    <?php	
			echo $resultados['nombre'] . " ";
			echo $resultados['apellido'];
			echo $resultados['bio'];
	?>
    </p>
	<img src="<?php echo $resultados['foto']; ?>" width=50%;>

	<?php
		}

		mysqli_free_result($consulta);
		mysqli_close($conexion);

	?>
</article>
</section>

</body>
<footer>&copy 2021- Producción Digital 3 - Araceli kim</footer>

</html>