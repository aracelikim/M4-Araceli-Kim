<?php
session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
</head>

<body>

<?php
$usuario = $_POST['usuario'];
$password = md5 ($_POST['password']);

$conexion = mysqli_connect('localhost', 'root','', 'pd3');

$consulta = mysqli_query($conexion, "SELECT nombre, apellido, email FROM usuarios WHERE usuario='$usuario' AND password='$password'");

$resultado = mysqli_num_rows($consulta);

if($resultado!=0){
	$respuesta=mysqli_fetch_array($consulta);
		echo "Hola ".$respuesta['nombre']." ".$respuesta['apellido']."<br />";
    $_SESSION['logueado']="ok";
	header('location:sesion2.php');
	
	
	
} else {
	echo "No es un usuario registrado";
	include ("conectarse.html");
}


?>

</body>
</html>