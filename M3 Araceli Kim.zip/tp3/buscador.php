<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>

	<form action="resultados_buscar.php" method="post">
    <label>Buscar Artistas
    <input type="search" name="buscar" placeholder="Buscar Artistas ..." />
    <input type="submit" value="Enviar">
    </label>
    </form>
</body>
</html>